/* Hizb Sabbih — garde l'application et les sons pour l'utiliser sans réseau. Les vidéos de lettres restent en lecture directe. */
var SHELL='hizb-shell-v1', PAGES='hizb-pages-v1';
self.addEventListener('install',function(e){self.skipWaiting();e.waitUntil(caches.open(SHELL).then(function(c){return c.addAll(['manifest.webmanifest','icon-192.png','icon-512.png']).catch(function(){});}));});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==SHELL&&k!==PAGES;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
function isPage(u){return /\/(hizb-v\d+|index)\.html$/.test(u.pathname)||/\/$/.test(u.pathname)||/\/sons-[0-9a-f]+\.json$/.test(u.pathname);}
self.addEventListener('fetch',function(e){
  var r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin||r.headers.has('range')||/\.mp4$/.test(u.pathname))return;          /* vidéos : pas touchées */
  if(isPage(u)){
    e.respondWith(fetch(r).then(function(res){
      if(res&&res.ok){var copy=res.clone();caches.open(PAGES).then(function(c){c.put(r,copy).then(function(){
        if(/hizb-v\d+\.html$/.test(u.pathname)){c.keys().then(function(ks){ks.forEach(function(k){if(/hizb-v\d+\.html$/.test(k.url)&&k.url.split('?')[0]!==r.url.split('?')[0])c.delete(k);});});}   /* on ne garde que la dernière version */
      });});}
      return res;
    }).catch(function(){return caches.match(r,{ignoreSearch:true}).then(function(m){return m||caches.match('./',{ignoreSearch:true});});}));
    return;
  }
  e.respondWith(caches.match(r).then(function(m){return m||fetch(r);}));
});
